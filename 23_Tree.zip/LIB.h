#pragma once
#ifndef __LIB_H__
#define __LIB_H__
#include<stdio.h>
#include<malloc.h>
#include<stdlib.h>
#include<time.h>
#include<string.h>
#include<Windows.h>
#include<math.h>

#endif