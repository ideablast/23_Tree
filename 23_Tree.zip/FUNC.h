#pragma once

#ifndef __FUNC_H__
#define __FUNC_H__

Node *Create_new_23_node();
int Count_node_data(Node *target_node);
nData Swap_in(nData target_nData);
int Range_checker(Node *target_node, int item);
int Type_of_node(Node *cur_node);
int Exception_check(Node *cur_node);
void Insert_23_node(Node * top, int item);
void Print_pre_order(Node *top);
int Search_depth(Node *top);

#endif
